package com.church.khidma
object Services{
 const val CHURCH="كنيسة الآباء الرسل الأطهار"
 val names=linkedMapOf("ابتدائي" to "مدارس الأحد — ابتدائي","إعدادي" to "اجتماع الشهيد مارمينا والقديسة تماف إيريني — فتيان وفتيات إعدادي","ثانوي" to "اجتماع القديسة دميانة والبابا كيرلس السادس لخدمة ثانوي","جامعة" to "اجتماع يوسف الصديق — جامعة وخرجين")
 val codes=mapOf("ابتدائي" to "1001","إعدادي" to "2002","ثانوي" to "3003","جامعة" to "4004")
 val days=mapOf("ابتدائي" to "الجمعة","إعدادي" to "الخميس","ثانوي" to "الثلاثاء","جامعة" to "السبت")
 val staff=linkedMapOf("أمين خدمة الأولاد" to "1111","أمينة خدمة البنات" to "2222","مساعد أمين الخدمة" to "3333","خادم شامل 1" to "4444","خادم شامل 2" to "5555","أمين الخدمة العام" to "9999")
 fun isAdmin(role:String)=role=="أمين الخدمة العام"||role.contains("أمين خدمة")||role.contains("أمينة خدمة")||role.contains("مساعد")||role.contains("خادم شامل")
}
data class StaffSession(val role:String,val service:String?,val gender:String?=null)

package com.church.khidma
import android.content.Context
import java.io.File
fun exportCsv(context:Context,service:String,db:Db):File{val f=File(context.getExternalFilesDir(null),"khidma_${service}.csv");f.writeText("\uFEFF"+db.csv(service),Charsets.UTF_8);return f}

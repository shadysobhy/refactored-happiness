package com.church.khidma

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

object SyncApi {
    // بعد نشر الـBackend ضع هنا رابط HTTPS الخاص به، مثال: https://your-app.onrender.com
    const val BASE_URL = "https://YOUR-BACKEND-URL-HERE"
    private val executor = Executors.newSingleThreadExecutor()

    fun sync(db: Db, done: (Boolean, String) -> Unit) {
        if (BASE_URL.contains("YOUR-BACKEND")) { done(false, "ضع رابط السيرفر في SyncApi.kt أولاً"); return }
        executor.execute {
            try {
                val payload = JSONObject()
                val members = JSONArray(); db.members().forEach { m -> members.put(JSONObject().apply { put("id",m.id);put("name",m.name);put("phone",m.phone);put("church",m.church);put("service",m.service);put("year",m.year);put("team",m.team);put("servant",m.servant);put("points",m.points) }) }
                val attendance = JSONArray(); db.allAttendance().forEach { a -> attendance.put(JSONObject().apply { put("memberId",a.memberId);put("date",a.date) }) }
                val contests = JSONArray(); db.contests().forEach { c -> contests.put(JSONObject().apply { put("id",c.id);put("title",c.title);put("question",c.question);put("service",c.service);put("createdAt",c.createdAt) }) }
                val answers = JSONArray(); db.allAnswers().forEach { a -> answers.put(JSONObject().apply { put("contestId",a.contestId);put("memberId",a.memberId);put("answer",a.answer);put("score",a.score);put("answeredAt",a.answeredAt) }) }
                payload.put("members",members);payload.put("attendance",attendance);payload.put("contests",contests);payload.put("answers",answers)
                val con = URL(BASE_URL.trimEnd('/')+"/api/sync").openConnection() as HttpURLConnection
                con.requestMethod="POST";con.connectTimeout=10000;con.readTimeout=15000;con.doOutput=true;con.setRequestProperty("Content-Type","application/json; charset=utf-8")
                con.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                val code=con.responseCode
                if(code !in 200..299) throw Exception("HTTP $code")
                val response=con.inputStream.bufferedReader().use{it.readText()}
                val snap=JSONObject(response).optJSONObject("snapshot")
                if(snap!=null){
                    val ms=snap.optJSONArray("members")?:JSONArray();for(i in 0 until ms.length()){val o=ms.getJSONObject(i);db.upsertMember(Member(o.getString("id"),o.optString("name"),o.optString("phone"),o.optString("church"),o.optString("service"),o.optString("year"),o.optString("team"),o.optString("servant"),o.optInt("points")))}
                    val at=snap.optJSONArray("attendance")?:JSONArray();for(i in 0 until at.length()){val o=at.getJSONObject(i);db.upsertAttendance(Attendance(o.getString("memberId"),o.getString("date")))}
                    val cs=snap.optJSONArray("contests")?:JSONArray();for(i in 0 until cs.length()){val o=cs.getJSONObject(i);db.upsertContest(Contest(o.getLong("id"),o.optString("title"),o.optString("question"),o.optString("service"),o.optString("createdAt")))}
                    val ans=snap.optJSONArray("answers")?:JSONArray();for(i in 0 until ans.length()){val o=ans.getJSONObject(i);db.upsertAnswer(Answer(o.getLong("contestId"),o.getString("memberId"),o.optString("answer"),o.optInt("score"),o.optString("answeredAt")))}
                }
                Handler(Looper.getMainLooper()).post{done(true,"تمت المزامنة بنجاح")}
            } catch(e:Exception){ Handler(Looper.getMainLooper()).post{done(false,"فشلت المزامنة: ${e.message}")} }
        }
    }
}

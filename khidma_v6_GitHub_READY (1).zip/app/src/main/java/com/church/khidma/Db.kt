package com.church.khidma

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

const val DB_VERSION=2
class Db(ctx: Context): SQLiteOpenHelper(ctx,"khidma.db",null,DB_VERSION){
 override fun onCreate(db: SQLiteDatabase){
  db.execSQL("CREATE TABLE members(id TEXT PRIMARY KEY,name TEXT,phone TEXT,church TEXT,service TEXT,year TEXT,team TEXT,servant TEXT,points INTEGER DEFAULT 0)")
  db.execSQL("CREATE TABLE attendance(id INTEGER PRIMARY KEY AUTOINCREMENT,memberId TEXT,date TEXT,UNIQUE(memberId,date))")
  db.execSQL("CREATE TABLE contests(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,question TEXT,service TEXT,createdAt TEXT)")
  db.execSQL("CREATE TABLE answers(id INTEGER PRIMARY KEY AUTOINCREMENT,contestId INTEGER,memberId TEXT,answer TEXT,score INTEGER DEFAULT 0,answeredAt TEXT,UNIQUE(contestId,memberId))")
 }
 override fun onUpgrade(db: SQLiteDatabase,old:Int,new:Int){
  if(old<2){
   db.execSQL("CREATE TABLE contests(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,question TEXT,service TEXT,createdAt TEXT)")
   db.execSQL("CREATE TABLE answers(id INTEGER PRIMARY KEY AUTOINCREMENT,contestId INTEGER,memberId TEXT,answer TEXT,score INTEGER DEFAULT 0,answeredAt TEXT,UNIQUE(contestId,memberId))")
  }
 }
 fun addMember(m:Member){writableDatabase.insert("members",null,ContentValues().apply{put("id",m.id);put("name",m.name);put("phone",m.phone);put("church",m.church);put("service",m.service);put("year",m.year);put("team",m.team);put("servant",m.servant);put("points",0)})}
 fun member(id:String)=readableDatabase.rawQuery("SELECT * FROM members WHERE id=?",arrayOf(id)).use{if(it.moveToFirst()) Member(it.getString(0),it.getString(1),it.getString(2),it.getString(3),it.getString(4),it.getString(5),it.getString(6),it.getString(7),it.getInt(8)) else null}
 fun members(service:String?=null)=readableDatabase.rawQuery(if(service==null)"SELECT * FROM members ORDER BY name" else "SELECT * FROM members WHERE service=? ORDER BY name",if(service==null)null else arrayOf(service)).use{c->buildList{while(c.moveToNext())add(Member(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6),c.getString(7),c.getInt(8)))}}
 fun attend(id:String,date:String):Boolean{val v=ContentValues().apply{put("memberId",id);put("date",date)};val ok=writableDatabase.insertWithOnConflict("attendance",null,v,SQLiteDatabase.CONFLICT_IGNORE)!=-1L;if(ok)writableDatabase.execSQL("UPDATE members SET points=points+1 WHERE id=?",arrayOf(id));return ok}
 fun hasAttendance(id:String,date:String)=readableDatabase.rawQuery("SELECT 1 FROM attendance WHERE memberId=? AND date=?",arrayOf(id,date)).use{it.moveToFirst()}
 fun promoteAll():Int{var count=0;val next=members();for(m in next){val newService=when(m.service){"ابتدائي"->if(m.year=="سنة ثالثة")"إعدادي" else m.service;"إعدادي"->if(m.year=="سنة ثالثة")"ثانوي" else m.service;"ثانوي"->if(m.year=="سنة ثالثة")"جامعة" else m.service;else->m.service};val newYear=if(m.year=="سنة أولى")"سنة ثانية" else if(m.year=="سنة ثانية")"سنة ثالثة" else "سنة أولى";if(newService!=m.service||newYear!=m.year){writableDatabase.execSQL("UPDATE members SET service=?,year=? WHERE id=?",arrayOf(newService,newYear,m.id));count++}};return count}
 fun allAttendance():List<Attendance>{return readableDatabase.rawQuery("SELECT memberId,date FROM attendance",null).use{c->buildList{while(c.moveToNext())add(Attendance(c.getString(0),c.getString(1)))}}}
 fun allAnswers():List<Answer>{return readableDatabase.rawQuery("SELECT contestId,memberId,answer,score,answeredAt FROM answers",null).use{c->buildList{while(c.moveToNext())add(Answer(c.getLong(0),c.getString(1),c.getString(2),c.getInt(3),c.getString(4)))}}}
 fun upsertMember(m:Member){val v=ContentValues().apply{put("id",m.id);put("name",m.name);put("phone",m.phone);put("church",m.church);put("service",m.service);put("year",m.year);put("team",m.team);put("servant",m.servant);put("points",m.points)};writableDatabase.insertWithOnConflict("members",null,v,SQLiteDatabase.CONFLICT_REPLACE)}
 fun upsertAttendance(a:Attendance){val v=ContentValues().apply{put("memberId",a.memberId);put("date",a.date)};writableDatabase.insertWithOnConflict("attendance",null,v,SQLiteDatabase.CONFLICT_IGNORE)}
 fun upsertContest(c:Contest){val v=ContentValues().apply{put("id",c.id);put("title",c.title);put("question",c.question);put("service",c.service);put("createdAt",c.createdAt)};writableDatabase.insertWithOnConflict("contests",null,v,SQLiteDatabase.CONFLICT_REPLACE)}
 fun upsertAnswer(a:Answer){val v=ContentValues().apply{put("contestId",a.contestId);put("memberId",a.memberId);put("answer",a.answer);put("score",a.score);put("answeredAt",a.answeredAt)};writableDatabase.insertWithOnConflict("answers",null,v,SQLiteDatabase.CONFLICT_IGNORE)}
 fun csv(service:String?):String{val sb=StringBuilder("الاسم,واتساب,الخدمة,السنة,الفريق,الخادم,النقاط\n");for(m in members(service))sb.append(listOf(m.name,m.phone,m.service,m.year,m.team,m.servant,m.points).joinToString(","){"\"${it.replace("\"","\"\"")}\""}).append('\n');return sb.toString()}
 fun addContest(title:String,question:String,service:String):Long{return writableDatabase.insert("contests",null,ContentValues().apply{put("title",title);put("question",question);put("service",service);put("createdAt",System.currentTimeMillis().toString())})}
 fun contests(service:String?=null):List<Contest>{return readableDatabase.rawQuery(if(service==null)"SELECT * FROM contests ORDER BY id DESC" else "SELECT * FROM contests WHERE service=? ORDER BY id DESC",if(service==null)null else arrayOf(service)).use{c->buildList{while(c.moveToNext())add(Contest(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4)))}}}
 fun answer(contestId:Long,memberId:String,answer:String):Boolean{val v=ContentValues().apply{put("contestId",contestId);put("memberId",memberId);put("answer",answer);put("answeredAt",System.currentTimeMillis().toString())};return writableDatabase.insertWithOnConflict("answers",null,v,SQLiteDatabase.CONFLICT_IGNORE)!=-1L}
 fun answered(contestId:Long):Set<String>{return readableDatabase.rawQuery("SELECT memberId FROM answers WHERE contestId=?",arrayOf(contestId.toString())).use{c->buildSet{while(c.moveToNext())add(c.getString(0))}}}
}
data class Member(val id:String,val name:String,val phone:String,val church:String,val service:String,val year:String,val team:String,val servant:String,val points:Int)
data class Contest(val id:Long,val title:String,val question:String,val service:String,val createdAt:String)
data class Attendance(val memberId:String,val date:String)
data class Answer(val contestId:Long,val memberId:String,val answer:String,val score:Int,val answeredAt:String)

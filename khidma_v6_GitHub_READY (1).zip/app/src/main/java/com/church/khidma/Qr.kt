package com.church.khidma
import android.graphics.Bitmap
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.common.BitMatrix
fun makeQr(text:String,size:Int=700):Bitmap{val m:BitMatrix=MultiFormatWriter().encode(text,BarcodeFormat.QR_CODE,size,size);val b=Bitmap.createBitmap(size,size,Bitmap.Config.RGB_565);for(x in 0 until size)for(y in 0 until size)b.setPixel(x,y,if(m[x,y])0xFF000000.toInt() else 0xFFFFFFFF.toInt());return b}

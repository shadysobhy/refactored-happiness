package com.church.khidma
import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

class ScannerActivity:AppCompatActivity(){
 lateinit var preview:PreviewView;lateinit var db:Db;var busy=false;val exec=Executors.newSingleThreadExecutor()
 override fun onCreate(b:Bundle?){super.onCreate(b);db=Db(this);val box=FrameLayout(this);preview=PreviewView(this);box.addView(preview);val t=TextView(this);t.text="وجّه الكاميرا إلى QR المخدوم";t.setTextColor(0xFFFFFFFF.toInt());t.textSize=20f;t.setPadding(20,40,20,20);box.addView(t);setContentView(box);start()}
 fun start(){val future=ProcessCameraProvider.getInstance(this);future.addListener({val provider=future.get();val p=Preview.Builder().build().also{it.surfaceProvider=preview.surfaceProvider};val a=ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build();val scanner=BarcodeScanning.getClient();a.setAnalyzer(exec){proxy->val media=proxy.image;if(media==null){proxy.close();return@setAnalyzer};val image=InputImage.fromMediaImage(media,proxy.imageInfo.rotationDegrees);scanner.process(image).addOnSuccessListener{codes->if(!busy){codes.firstOrNull()?.rawValue?.let{record(it)}}}.addOnCompleteListener{proxy.close()}};provider.unbindAll();provider.bindToLifecycle(this,CameraSelector.DEFAULT_BACK_CAMERA,p,a)},ContextCompat.getMainExecutor(this))}
 fun record(id:String){busy=true;val service=intent.getStringExtra("service");val m=db.member(id);if(m==null|| (service!=null&&m.service!=service)){Toast.makeText(this,"QR غير تابع لهذا الاجتماع",Toast.LENGTH_LONG).show();busy=false;return};val d=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date());val ok=db.attend(id,d);Toast.makeText(this,if(ok)"تم تسجيل حضور ${m.name}" else "الحضور مسجل بالفعل",Toast.LENGTH_LONG).show();busy=false}
 override fun onDestroy(){exec.shutdown();super.onDestroy()}
}

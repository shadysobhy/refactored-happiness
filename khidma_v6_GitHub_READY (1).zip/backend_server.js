const http = require('http');
const fs = require('fs');
const path = require('path');
const PORT = process.env.PORT || 8080;
const DATA = path.join(__dirname, 'data.json');
let db = fs.existsSync(DATA) ? JSON.parse(fs.readFileSync(DATA,'utf8')) : {members:[],attendance:[],contests:[],answers:[]};
function save(){fs.writeFileSync(DATA, JSON.stringify(db,null,2));}
function json(res, code, obj){res.writeHead(code, {'Content-Type':'application/json; charset=utf-8','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'GET,POST,OPTIONS'});res.end(JSON.stringify(obj));}
function body(req){return new Promise((resolve,reject)=>{let s='';req.on('data',c=>s+=c);req.on('end',()=>{try{resolve(s?JSON.parse(s):{})}catch(e){reject(e)}})})}
function id(prefix){return prefix+'-'+Date.now()+'-'+Math.random().toString(36).slice(2,8)}
const server=http.createServer(async(req,res)=>{
 if(req.method==='OPTIONS') return json(res,204,{});
 try{
  if(req.method==='GET' && req.url==='/api/health') return json(res,200,{ok:true,church:'كنيسة الآباء الرسل الأطهار'});
  if(req.method==='GET' && req.url==='/api/snapshot') return json(res,200,db);
  if(req.method==='POST' && req.url==='/api/sync'){
   const x=await body(req);
   for(const m of (x.members||[])){const i=db.members.findIndex(a=>a.id===m.id); if(i<0)db.members.push(m); else db.members[i]={...db.members[i],...m};}
   for(const a of (x.attendance||[])){if(!db.attendance.some(v=>v.memberId===a.memberId&&v.date===a.date))db.attendance.push(a);}
   for(const c of (x.contests||[])){if(!db.contests.some(v=>String(v.id)===String(c.id)))db.contests.push(c);}
   for(const a of (x.answers||[])){if(!db.answers.some(v=>String(v.contestId)===String(a.contestId)&&v.memberId===a.memberId))db.answers.push(a);}
   save(); return json(res,200,{ok:true,snapshot:db});
  }
  return json(res,404,{error:'not found'});
 }catch(e){return json(res,500,{error:e.message})}
});
server.listen(PORT,()=>console.log(`Khidma backend listening on ${PORT}`));

# تشغيل المشروع وإخراج APK أونلاين

## 1) بناء APK تلقائيًا
ارفع المشروع إلى GitHub في Repository جديد. عند كل Push إلى main أو عند تشغيل Workflow يدويًا:
GitHub Actions > Build Android APK > Run workflow.

بعد نجاح البناء افتح تبويب Actions ثم نتيجة التشغيل ثم Artifacts وحمّل `khidma-apk`.

## 2) نشر السيرفر
المشروع يحتوي على `render.yaml` و`package.json`.
على Render أنشئ Web Service من مستودع GitHub، أو استخدم Blueprint إذا كان المستودع عامًا.
Build Command: npm install
Start Command: node backend_server.js
Health Check: /api/health

بعد النشر سيظهر رابط مثل https://اسم-الخدمة.onrender.com.
ضع الرابط في `SyncApi.kt` بدل `https://YOUR-BACKEND-URL-HERE`، ثم شغّل Workflow مرة أخرى لإخراج APK مرتبط بالسيرفر.

ملاحظة: السيرفر الحالي يستخدم ملف JSON للتجربة. التخزين على نظام الملفات في خدمة سحابية قد لا يكون دائمًا عند إعادة التشغيل؛ قبل الاستخدام الفعلي يفضل نقله إلى قاعدة بيانات مثل Postgres.
